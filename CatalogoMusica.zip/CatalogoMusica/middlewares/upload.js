import multer from 'multer';
import path from 'path';

const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, 'public/uploads');
    },
    filename: (req, file, cb) => {
        const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
        cb(null, uniqueSuffix + path.extname(file.originalname));
    }
});

const fileFilter = (req, file, cb) => {
    const allowedTypes = /mp3|m4a|ogg|wav|jpeg|jpg|png/; // Tipos permitidos
    const extname = allowedTypes.test(path.extname(file.originalname).toLowerCase());
    const mimetype = allowedTypes.test(file.mimetype);

    if (extname && mimetype) {
        cb(null, true);
    } else {
        cb(new Error('Formato de arquivo inválido! Apenas MP3, M4A, OGG, WAV e imagens (JPEG, PNG) são permitidos.'));
    }
};

const upload = multer({
    storage,
    fileFilter,
    limits: { fileSize: 10 * 1024 * 1024 } // Aumentando o limite para 10 MB
});

// Middleware para múltiplos campos
export const handleFileUpload = (fields) => (req, res, next) => {
    const uploadMiddleware = upload.fields([
        { name: 'capa', maxCount: 1 },  // Para 1 arquivo de capa
        { name: 'audio', maxCount: 10 } // Para 10 arquivos de áudio (audio[] no formulário)
    ]);
    
    uploadMiddleware(req, res, (err) => {
        if (err instanceof multer.MulterError) {
            req.flash('error_msg', 'Erro no upload: ' + err.message);
            console.log(err);
        } else if (err) {
            req.flash('error_msg', err.message);
        }
        if (err) {
            return res.redirect('/discos/adicionarDiscos');
        }
        next();
    });
};

export default upload;
